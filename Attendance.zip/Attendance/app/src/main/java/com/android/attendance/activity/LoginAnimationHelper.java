package com.android.attendance.activity;

import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;

import com.example.androidattendancesystem.R;

/**
 * Helper class to handle animations for the login screen
 */
public class LoginAnimationHelper {

    /**
     * Apply animations to login screen elements
     * @param logoImageView The logo image view
     * @param titleLayout The title layout
     * @param loginLayout The login card layout
     * @param buttonLogin The login button
     * @param spinnerLoginAs The login spinner
     */
    public static void applyAnimations(ImageView logoImageView, LinearLayout titleLayout, 
                                      LinearLayout loginLayout, Button buttonLogin, Spinner spinnerLoginAs) {
        // Load animations
        Animation fadeIn = AnimationUtils.loadAnimation(logoImageView.getContext(), R.anim.fade_in);
        Animation slideUp = AnimationUtils.loadAnimation(logoImageView.getContext(), R.anim.slide_up);
        Animation slideInRight = AnimationUtils.loadAnimation(logoImageView.getContext(), R.anim.slide_in_right);
        
        // Set animation delays for sequence effect
        fadeIn.setStartOffset(300);
        slideUp.setStartOffset(500);
        slideInRight.setStartOffset(800);
        
        // Apply animations to views
        logoImageView.startAnimation(fadeIn);
        titleLayout.startAnimation(fadeIn);
        loginLayout.startAnimation(slideUp);
        buttonLogin.startAnimation(slideInRight);
        
        // Initially hide views and make them visible with animation
        logoImageView.setVisibility(View.VISIBLE);
        titleLayout.setVisibility(View.VISIBLE);
        loginLayout.setVisibility(View.VISIBLE);
        buttonLogin.setVisibility(View.VISIBLE);
    }
}